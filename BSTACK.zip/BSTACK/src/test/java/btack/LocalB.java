package btack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

public class LocalB {
    @Test
    public void testLoginAndAddToCart() {
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            driver.get("https://www.saucedemo.com");

            WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
            WebElement password = driver.findElement(By.id("password"));
            WebElement loginButton = driver.findElement(By.id("login-button"));

            username.sendKeys("standard_user");
            password.sendKeys("secret_sauce");
            loginButton.click();

            driver.findElement(By.xpath("//div[normalize-space()='Sauce Labs Backpack']")).click();
            driver.findElement(By.xpath("//button[@id='add-to-cart']")).click();
            driver.findElement(By.xpath("//button[@id='back-to-products']")).click();
            driver.findElement(By.xpath("//a[@class='shopping_cart_link']")).click();

            WebElement removeButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='remove-sauce-labs-backpack']")));
            Assert.assertTrue(removeButton.isDisplayed(), "Remove button not visible, login/cart  failed.");

            System.out.println("Test Passed: User successfully logged in and item added to cart.");
        } 
        
        catch (Exception e) {
            System.out.println("Test Failed: Exception occurred - " + e.getMessage());
            
        }

    }
}