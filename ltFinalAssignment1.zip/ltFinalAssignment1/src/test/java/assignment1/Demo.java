package assignment1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo {
	
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver dr = new ChromeDriver();
		dr.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		dr.manage().window().maximize();
		Thread.sleep(Duration.ofSeconds(5));
		
		
		WebElement addMore= dr.findElement(By.xpath("//h4[text()=\"Brocolli - 1 Kg\"]/following-sibling::div[1]/a[2]"));
		addMore.click();
		
		Thread.sleep(Duration.ofSeconds(3));
		
		WebElement addToCart= dr.findElement(By.xpath("//h4[text()=\"Brocolli - 1 Kg\"]/following-sibling::div[2]/button"));
		addToCart.click();
		Thread.sleep(Duration.ofSeconds(3));
		
		WebElement detailAddToCart= dr.findElement(By.xpath("//img[@src=\"https://rahulshettyacademy.com/seleniumPractise/images/bag.png\"]"));
		detailAddToCart.click();
		Thread.sleep(Duration.ofSeconds(3));
		
		WebElement paymentPage= dr.findElement(By.xpath("//button[text()=\"PROCEED TO CHECKOUT\"]"));
		paymentPage.click();
		Thread.sleep(Duration.ofSeconds(3));
	}

}
