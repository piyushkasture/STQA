package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Assignment1 {

	WebDriver driver;
	public static final String USERNAME = "piyushkasture_4vL57j";
	public static final String ACCESS_KEY = "tn8iMrsa8uNxptssAAzp";
	public static final String BROWSERSTACK_URL = "https://" + USERNAME + ":" + ACCESS_KEY
			+ "@hub-cloud.browserstack.com/wd/hub";

	WebDriverWait wait;

	public void markTestStatus(String status, String reason, WebDriver driver) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("browserstack_executor: {\"action\":\"setSessionStatus\", \"arguments\":{\"status\":\""
				+ status + "\", \"reason\": \"" + reason + "\"}}");
	}

	@Parameters({ "os", "osVersion", "browserName", "browserVersion", "device", "realMobile" })
	@BeforeMethod
	public void setUp(String os, String osVersion,
	                  String browserName, String browserVersion,
	                  String device, String realMobile) throws Exception {

	    DesiredCapabilities caps = new DesiredCapabilities();
	    HashMap<String, Object> bstackOptions = new HashMap<>();

	    if (realMobile.equalsIgnoreCase("true")) {
	        bstackOptions.put("deviceName", device);
	        bstackOptions.put("realMobile", true);
	        bstackOptions.put("osVersion", osVersion);
	    } else {
	        bstackOptions.put("os", os);
	        bstackOptions.put("osVersion", osVersion);
	        caps.setCapability("browserName", browserName);
	        caps.setCapability("browserVersion", browserVersion);
	    }

	    bstackOptions.put("projectName", "My TestNG Project");
	    bstackOptions.put("buildName", "TestNG Build 1.0");
	    bstackOptions.put("sessionName", "Add Product Test");

	    caps.setCapability("bstack:options", bstackOptions);

	    driver = new RemoteWebDriver(new URL(BROWSERSTACK_URL), caps);
	    wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    if (!realMobile.equalsIgnoreCase("true")) {
	        driver.manage().window().maximize();
	    }
	}



	@Test(priority = 1)
	public void testAddProduct() throws InterruptedException {
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
//		driver.manage().window().maximize();
//		Thread.sleep(Duration.ofSeconds(5));
		try {

			WebElement addMore = wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//h4[text()=\"Brocolli - 1 Kg\"]/following-sibling::div[1]/a[2]")));
			addMore.click();

			Thread.sleep(Duration.ofSeconds(3));

			WebElement addToCart = driver
					.findElement(By.xpath("//h4[text()=\"Brocolli - 1 Kg\"]/following-sibling::div[2]/button"));
			addToCart.click();
			Thread.sleep(Duration.ofSeconds(3));

			WebElement detailAddToCart = driver.findElement(
					By.xpath("//img[@src=\"https://rahulshettyacademy.com/seleniumPractise/images/bag.png\"]"));
			detailAddToCart.click();
			Thread.sleep(Duration.ofSeconds(3));

			WebElement paymentPage = driver.findElement(By.xpath("//button[text()=\"PROCEED TO CHECKOUT\"]"));
			paymentPage.click();
			Thread.sleep(Duration.ofSeconds(3));

			WebElement amount = driver.findElement(By.xpath("//b[text()=\"Total Amount     : \"]"));

			Assert.assertTrue(amount.isDisplayed(), "Item visible");

			markTestStatus("passed", "Item successfully added to cart.", driver);

			System.out.println("Item successfully added to cart");
		} catch (Exception e) {
			markTestStatus("failed", "Item not added in cart: " + e.getMessage(), driver);
			Assert.fail("Test failed: " + e.getMessage());
		}
	}

	@AfterMethod
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}

}
